﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgroAppDomain.Model.Response
{
    public class GraficaAmbienteResult
    {
        public string captura { get; set; }
        public double valor { get; set; }
    }
}
