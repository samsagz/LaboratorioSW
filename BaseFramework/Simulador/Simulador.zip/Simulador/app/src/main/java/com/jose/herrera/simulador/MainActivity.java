package com.jose.herrera.simulador;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button send;
    private EditText fecha;
    private EditText variableAmbiente;
    private EditText valor;
    private EditText moduloId;
    private TextView agroResponse;
    private HandlerThread simulacion;
    Handler simulacionHandler;
    private boolean started;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        send = findViewById(R.id.send);

        fecha = findViewById(R.id.fecha);

        variableAmbiente = findViewById(R.id.variableAmbiente);

        valor = findViewById(R.id.valor);

        moduloId = findViewById( R.id.moduloId);

        agroResponse = findViewById(R.id.agroResponse);

        simulacion = new HandlerThread("simulacion");

        simulacion.start();

        simulacionHandler = new Handler(simulacion.getLooper());

        send.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                started = ! started;

                if(started) {

                    send.setText("detener");

                }else {

                    send.setText("iniciar");

                }

                start();

            }

        });

    }


    public void start() {

            simulacionHandler.postDelayed( new Runnable() {

                @Override
                public void run() {

                    if(started) {

                        AgroRemote.postAgro(fecha.getText().toString(), variableAmbiente.getText().toString(),

                                Double.parseDouble(valor.getText().toString()), Integer.parseInt(moduloId.getText().toString()), new AgroCompletion() {

                                    @Override
                                    public void onGetAgro(AgroResponse agroResponse, String message) {

                                        Log.e("POST","Agro");

                                        send.setEnabled(true);

                                        if (agroResponse != null) {

                                            String text = agroResponse.mensaje;

                                            for (String string : agroResponse.actuadores) {

                                                text = text + " " + string;

                                            }

                                            MainActivity.this.agroResponse.setText(text);

                                        } else {

                                            MainActivity.this.agroResponse.setText(message);

                                        }

                                        start();

                                    }

                                });

                    }
                }

            },10000);

    }

}