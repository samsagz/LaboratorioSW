package com.jose.herrera.simulador;

public class AgroEndpoints {

    public static final String URL_BASE = "https://serviciosgranja.azurewebsites.net/api/";
    public static final String POST_AGRO = "AgroApi";


}
