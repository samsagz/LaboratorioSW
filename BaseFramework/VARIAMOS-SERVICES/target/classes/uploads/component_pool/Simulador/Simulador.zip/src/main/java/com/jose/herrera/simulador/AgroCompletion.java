package com.jose.herrera.simulador;

public interface AgroCompletion {

    void onGetAgro(AgroResponse agroResponse, String message);

}
